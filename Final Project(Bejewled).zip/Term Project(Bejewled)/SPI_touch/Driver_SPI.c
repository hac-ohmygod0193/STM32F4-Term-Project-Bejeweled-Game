/* type change */
typedef unsigned char       bool;

/* INCLUDES */
#include "stm32f4xx.h"
#define pin_0 0
#define pin_1 1
#define pin_2 2
#define pin_8 8
#define pin_9 9
#define pin_10 10

#ifndef Bit
#define Bit(x) 	(1ul<<x)
#endif


/*-------------------------------------------------------------------------------------------------------
*  ����n��
-------------------------------------------------------------------------------------------------------*/
//touch
/* --- include following 7 lines in *.h ----
void Driver_SPICS(bool sta);
void Driver_SPISCK(bool sta);
void Driver_SPIMOSI(bool sta);
bool Driver_SPIMISO(void);

void Delay_SPI(uint16_t Num);
void Touch_SPIWrite(uint8_t Val);
uint16_t Touch_SPIRead(void);
*/
//key
//-------------------------------------------------------------------------------------------------------
//-------------------------------------- TOUCH SPI DRIVER -----------------------------------------------
//-------------------------------------------------------------------------------------------------------
void Driver_SPIpin_GPIO(void)
/*  --------------------------------------------------------------
    GPIOB: OUTPUT, Speed_25MHz medium, push pull, no pull
	  --------------------------------------------------------------
	  | Pin: PB |     1      2
    | SPI     |    SCK    CS
    | initial |   0(low)  1(high)
	  --------------------------------------------------------------
*/
{
	#define  cc1   ((0x03ul<<pin_1*2)|(0x03ul<<pin_2*2))    	// 111100b
	#define  bb1   ((0x01ul<<pin_1*2)|(0x01ul<<pin_2*2))    	// 010100b
		RCC->AHB1ENR |=  (1UL << 1);     // enable clock for GPIOB
	// 0:PORTA, 1: PORTB, ..., 10: PORTK
		GPIOB->BSRR = Bit(1)<<16;	// Initial output value for SCK = 0
		GPIOB->BSRR = Bit(2);			// Initial output value for CS = 1
    GPIOB->MODER   = (GPIOB->MODER & ~cc1 )  | bb1; // MODE
		GPIOB->OSPEEDR = (GPIOB->OSPEEDR & ~(0x03ul << (pin_1 * 2))) | (0x01ul << (pin_1 * 2));    // Output Speed
    GPIOB->OTYPER  &= ~(Bit(1)|Bit(2));         	  // (=>0x0) Output Type
    GPIOB->PUPDR   &= ~(Bit(1)|Bit(2));  			                    // (=>0x0) Pull-up Pull-down
		GPIOB->AFR[0]  &= ~(0x0FFul<<pin_1*4);     			// (=>0x0FF0) AF: System or Alternate Function
/*  --------------------------------------------------------------
    GPIOF: OUTPUT, Speed_25MHz medium, push pull, no pull
		--------------------------------------------------------------
	  | Pin: PF |        9
    | SPI     |      MOSI
	  --------------------------------------------------------------
*/
		RCC->AHB1ENR |=  (1UL << 5);     // enable clock for GPIOF
	// 0:PORTA, 1: PORTB, ..., 10: PORTK
		GPIOF->MODER   = (GPIOF->MODER & ~(0x03ul<<(pin_9*2)) ) | (0x01ul<<(pin_9*2)); // MODE 01b
		GPIOF->OSPEEDR = (GPIOF->MODER & ~(0x03ul<<(pin_9*2)) ) | (0x01ul<<(pin_9*2));    // Output Speed 01b
    GPIOF->OTYPER  &= ~~(0x01ul << pin_9) ;         	  // (=>0x0) Output Type 0b
    GPIOF->PUPDR   &= (0x03ul<<(pin_9*2));			         // (=>0x0) Pull-up Pull-down 00b
		GPIOF->AFR[1]  &= ~(0x0FFul<<(pin_9 - pin_9)*9);    			// (=>0x0FF0) AF: System or Alternate Function
/*  --------------------------------------------------------------
    GPIOF: INPUT, float
		--------------------------------------------------------------
	  | Pin: PF |      8
    | SPI     |    MISO
	  --------------------------------------------------------------
*/
//  	RCC->AHB1ENR |=  (1UL << 5);     // enable clock for GPIOF
	// 0:PORTA, 1: PORTB, ..., 10: PORTK
    GPIOF->MODER   = (GPIOF->MODER & ~(0x03ul<<(pin_8*2)) ); // MODE 
    GPIOF->PUPDR   = (GPIOF->PUPDR & ~(0x03ul<<(pin_8*2)) ); // Pull-up Pull-down
    GPIOF->AFR[1]  &= ~(0x0Ful<<(pin_8 - pin_8)*4);          // AF: System or Alternate Function
				
				
				
}

#define CS_pin 		Bit(2)
#define SCK_pin 	Bit(1)
#define MISO_pin 	Bit(8)
#define MOSI_pin 	Bit(9)

/********************************************************************************************************
*  Function: Driver_SPICS		(CS = PB2)
*  Object: touch ic spi enable/unable
*  Input: 1/0
*  Output: none
*  brief:	set CS = 0 if sta=0; CS = 1 if sta = 1.
********************************************************************************************************/
void Driver_SPICS(bool sta)
{
		if(!sta) // sta = 0
			GPIOB->BSRR =CS_pin<<16;// reset ==> 0
		else
			GPIOB->BSRR =CS_pin;		// set ==> 1
}

/********************************************************************************************************
*  Function: Driver_SPIMISO		(MISO = PF8)
*  Object: SPI_MOSI
*  Input: none
*  Output: 1 if MISO=1; 0 if MISO = 0
*  brief:	none
********************************************************************************************************/
bool Driver_SPIMISO(void)
{
		  if ((GPIOF->IDR & MISO_pin))
				return 1;	// if MISO = 1
			else
				return 0; // if MISO = 0
}

/********************************************************************************************************
*  Function: Driver_SPIMOSI		(MOSI = PF9)
*  Object: SPI_MOSI
*  Input: 1/0
*  Output: none
*  brief:	set MOSI = 0 if sta=0; MOSI = 1 if sta = 1.
********************************************************************************************************/
void Driver_SPIMOSI(bool sta)
{
		if (!sta) // sta = 0
        GPIOF->BSRR = MOSI_pin<<16; // Set MOSI pin to 0 using BSRR register
    else
        GPIOF->BSRR = MOSI_pin;
}

/********************************************************************************************************
*  Function: Driver_SPISCK		(SCK = PB1)
*  Object: SPI_SCK
*  Input: 1/0
*  Output: none
*  brief:	set SCK = 0 if sta=0; SCK = 1 if sta = 1.
********************************************************************************************************/
void Driver_SPISCK(bool sta)
{
		if (!sta) // sta = 0
        GPIOB->BSRR = SCK_pin<<16; // Set SCK pin to 0 using BSRR register
    else
        GPIOB->BSRR = SCK_pin; // Set SCK pin to 1 using BSRR register
}

/*-------------------------------------------------------------------------------------------------------
*  Ĳ�NIC�q�H�N�X
*  SPI mode: (CPOL:CPHA)= (0:0), MSBit (Commands: 8 bits; Data: 12 bits (16 bits)
-------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------------
*  �{������,����SPI�ɧǨϥ�
-------------------------------------------------------------------------------------------------------*/
void Delay_SPI(uint16_t Num)
{
		volatile uint16_t Timer;
		while(Num--)
		{
		 	Timer = 20;
			while(Timer--);
		}
}

//--------- �qSPI�����������
uint16_t Touch_SPIRead(void)
{
    uint8_t i;
    uint16_t Val = 0;

//	for(i=0; i<12; i++)			// 12-bit data: max value = 4095
													  // the least 4 significant bits are ignorable
	for(i=0; i<16; i++)			// 16-bit data: max value = 65536
		{
        Val <<= 1;
#ifndef Test_Case2
        Driver_SPISCK(1);	// master captures data
			  Delay_SPI(1);
#endif
        Driver_SPISCK(0);	// slave loads data
				Delay_SPI(1);
        if(Driver_SPIMISO()){ // if MISO is high
					Val++;
				}
#ifdef Test_Case2
				Driver_SPISCK(1);	// master captures data
				Delay_SPI(1);
#endif
    }
#ifdef Test_Case2
				Driver_SPISCK(0);	// idle mode
				Delay_SPI(1);
#endif
		
    return Val;
}


//--------- ��SPI�����o�e���
void Touch_SPIWrite(uint8_t Val)
{
    uint8_t i;
    Driver_SPISCK(0);			// make sure that the idle clock is low
    for(i=0; i<8; i++)		// 8 bit mode
		{
				if(Val & Bit(7)) // most significant bit first
					Driver_SPIMOSI(1); // if Bit value = 1
				else
					Driver_SPIMOSI(0); // if Bit value = 0

				Val <<= 1;
        Driver_SPISCK(0);	// load at the FALLing edge of SCK clock
				Delay_SPI(1);					// hold half period
        Driver_SPISCK(1);	// capture at the RISing edge of SCK Clock
				Delay_SPI(1);					// hold half period
    }
		Driver_SPISCK(0);			// idle mode
		Delay_SPI(1);
}

