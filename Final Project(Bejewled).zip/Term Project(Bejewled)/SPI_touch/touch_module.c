#include "stm32f4xx.h"
#include "stm324xg_lcd_sklin.h"

typedef unsigned char       bool;
#define  True  1
#define  False 0

//#define ShowTouchValues

#ifdef ShowTouchValues
#include <string.h>
#include <stdio.h>
#endif


uint8_t Calibration_Done=0;
int32_t  X1, Y1, Xx, Yx, Xy, Yy ;

typedef struct
{
  uint16_t TouchDetected;
  uint16_t x;
  uint16_t y;
}TS_StateTypeDef;


/*-------------------------------------------------------------------------------------------------------
*  SPI driver
-------------------------------------------------------------------------------------------------------*/

void Driver_SPICS(bool sta);
bool Driver_SPIMISO(void);
void Driver_SPIMOSI(bool sta);
void Driver_SPISCK(bool sta);

void Delay_SPI(uint16_t Num);
void Touch_SPIWrite(uint8_t Val);
uint16_t Touch_SPIRead(void);
//=================
void Cal_GetXY(uint16_t* pX, uint16_t* pY);


__WEAK void delay_ms(uint32_t wait_ms){
	Delay_SPI(wait_ms);
}

/********************************************************************************************************
*  Function:
*  Object:
*  Input: pX and pY: pointers of the buffers for X and Y values
*  Output:
*  brief:	Get X and Y values of the touched point.
********************************************************************************************************/
void Touch_GetVal(uint16_t *pX, uint16_t *pY)
{
    Driver_SPICS(0);				// enable chip by pull down CS pin
		//--------------------
		Touch_SPIWrite(0xd0);   // send 0xd0 to ask Ū��X�b �˴���
    *pX = Touch_SPIRead();	// read data X and save in buffer
		Touch_SPIWrite(0x90);   // send 0x90 to ask Ū��Y�b �˴���
    *pY = Touch_SPIRead();	// read data Y and save in buffer
    //--------------------
		Driver_SPICS(1);			// disable chip by pull up CS pin
}


/********************************************************************************************************
*  Function: TSC_TouchDet		(PF10)
*  Object: touch module IRQ
*  Input: none
*  Output: 0/1
*  brief:	none
********************************************************************************************************/
#ifndef Bit
#define Bit(x) 	(0x01ul<<x)
#endif
#define TP_INT_IN   ( (GPIOF->IDR & Bit(10)) >> 10)		// PF10

uint32_t TSC_TouchDet (uint16_t Cnum)
{
	uint16_t  x1, y1, x2, y2, count;

	count = Cnum;
		//###====
    if( !(TP_INT_IN) )
    {
			if(--count == 0) return 1;
			while (1)
			{
				Touch_GetVal(&x1, &y1);   // get x, y from touch module
				delay_ms(10);
				if( TP_INT_IN ) break;
				Touch_GetVal(&x2, &y2);   // get x, y from touch module
				if ((-3 < (x2-x1) && (x2-x1) < 3)  && (-3< (y2-y1) && (y2-y1) < 3 ) )
				{
					if(--count == 0) return 1;
				} else {
					break;
				}
			}
 		}

		return 0;
}


//==================================================
void TS_GetState(TS_StateTypeDef* pTS_State)
{
		uint16_t x, y;
#ifdef ShowTouchValues
		char text[64];
#endif

		if (TSC_TouchDet(1)) {           // Show touch screen activity
				Touch_GetVal(&x, &y);   // get x, y from touch module
				pTS_State->TouchDetected=1;
			}
			else {
				pTS_State->TouchDetected=0;
				pTS_State->x = 0;
				pTS_State->y = 0;
				x= 0;
				y= 0;
			}

//==========>>>>>>>>>>>>>>
#ifdef ShowTouchValues
			sprintf(text, "X:%04d Y:%04d P=%01d", x, y, pTS_State->TouchDetected);
			LCD_SaveFont();
			LCD_SaveColors();
			LCD_SetFont(&Font16);
			LCD_SetColors(LCD_COLOR_RED, LCD_COLOR_WHITE); // Text = red; back = white
			LCD_DisplayStringLineCol(12, 2, text);
			LCD_RestoreColors();
			LCD_RestoreFont();
#endif
//<<<<==================================

			if (pTS_State->TouchDetected)
			{
				Cal_GetXY(&x, &y);
				pTS_State->x = x;
				pTS_State->y = y;
			}
}

/**
  * @brief
  * @param  None
  * @retval None
  */
void Touch_sensing(uint16_t Cnum, uint16_t xp, uint16_t yp, uint16_t width, uint16_t height)
{
	uint16_t x, y, count;

	count = Cnum;
	while (1)
  {
		if (TSC_TouchDet(1)) {           // Show touch screen activity
				Touch_GetVal(&x, &y);   // get x, y from touch module
			  Cal_GetXY(&x, &y);
		//###====
      if((y >= yp)&& (y < yp+height) )
      {
        if( (x >= xp) &&	(x < xp+width) )
        {
					if(--count == 0) return;
        }
      }
 		} else
		{
			count = Cnum;
		}
		delay_ms(10);
	}
}

/**
  * @brief
  * @param  None
  * @retval None
  */
void WaitForTouchRelease(uint32_t Cnum)
{
	uint32_t count;

	count = Cnum;
  do
  {
    delay_ms(1);
		if (TSC_TouchDet(1) == 0)
    {
      if(--count == 0) return;
		} else
		{
			count = Cnum;
		}
  } while (1);
}

#define TouchValue_16bits
#ifdef	TouchValue_16bits
	#define Q_format 16384 // Q14
	#define timesV	16
#else			// TouchValue_12bits
	#define Q_format 1024 // Q10
	#define timesV	1
#endif
/**
  * @brief  Calibrate X and Y position
  * @param  x, y : X, Y touch position
  * @retval calibrated y = (B1 + A1*y) / Q_format;
  */
void Cal_GetXY(uint16_t* pX, uint16_t* pY)
{
  int32_t x, y, temp;
//----- 3 parameters calibration
	x = *pX;
	y = *pY;
	temp = (X1 + (Xx * x) + (Xy * y))/(Q_format);
	y = (Y1 + (Yy * y) + (Yx * x))/(Q_format);
//<<<=============================
	x = temp;
	if (x < 0) x = 0;
	if (y < 0) y = 0;

	*pX = x;
	*pY = y;
}

//=====================================
void Default_Calibration(void)
{
  if (LCD_Pixel_Width() == 320)
	{
				// X axis
				X1 = -32848*timesV;
				Xx = 0;
				Xy = 92;
				// Y axis
				Y1 = 255864*timesV;
				Yy = 0;
		    Yx = -66;
	} else
	{
				// X axis
				X1 = -12525*timesV;
				Xx = 65;
				Xy = 0;
				// Y axis
				Y1 = -33962*timesV;
				Yy = 91;
		    Yx = 0;
	}
}

