#include "stdint.h"
#include "stm324xg_lcd_sklin.h"
#include <stdio.h>
typedef unsigned char       bool;

typedef struct
{
  uint16_t TouchDetected,x,y;
}TS_StateTypeDef; 

void Touch_GetVal(uint16_t *pX, uint16_t *pY);
// --- include following 7 lines in *.h ----
void Driver_SPICS(bool sta);
void Driver_SPISCK(bool sta);
void Driver_SPIMOSI(bool sta);
bool Driver_SPIMISO(void);

void Delay_SPI(uint16_t Num);
void Touch_SPIWrite(uint8_t Val);
uint16_t Touch_SPIRead(void);