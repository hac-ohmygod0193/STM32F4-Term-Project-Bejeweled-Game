#ifdef Test_SPI_pin_Settings
		uint8_t temp1;
	GPIOF->BSRR = Bit(9)<<16;
			  if (GPIOF->IDR & Bit(9))
				{
					LCD_DisplayStringLineCol(2, 4, "1. PF9 outputs \"1\"" );		
					LCD_DisplayStringLineCol(3, 2, "ERROR in setting PF9" );
					while(1);
				}
				else
					LCD_DisplayStringLineCol(2, 4, "1. PF9 outputs \"0\"" );		
	GPIOF->BSRR = Bit(9);
			  if (GPIOF->IDR & Bit(9))
				{
					LCD_DisplayStringLineCol(3, 4, "2. PF9 outputs \"1\"" );		
					LCD_DisplayStringLineCol(4, 2, "PF9 setting succeeds." );
				}
				else
				{
					LCD_DisplayStringLineCol(3, 4, "2. PF9 outputs \"0\"" );		
					LCD_DisplayStringLineCol(4, 2, "ERROR in setting PF9" );
					while(1);
				}					

	//=================
	LCD_SetBackColor(CYAN2);
	LCD_DisplayStringLineCol(8, 5, "Press KEY1" );		
	Wait_PressPA0(10);	
	while(GPIOA->IDR & Bit(0))			// wait until release KEY1
//====================================
	if ((GPIOB->IDR & (Bit(1)| Bit(2))) != 0x04)
	{
					LCD_DisplayStringLineCol(2, 2, "ERROR in setting PB" );
					while(1);
	}
	GPIOB->BSRR = Bit(2)<<16;
	GPIOB->BSRR = Bit(1);
	if ((GPIOB->IDR & (Bit(1)| Bit(2))) != 0x02)
	{
					LCD_DisplayStringLineCol(2, 2, "ERROR in setting PB" );
					while(1);
	}
	else
					LCD_DisplayStringLineCol(2, 2, "PB setting succeeds." );

//======== Input GPIO PF8 setting Checking ===============
					LCD_SetColors(WHITE, DARKGRAY);
					LCD_DisplayStringLineCol(4, 5, "PF8 inputs " );		
					LCD_DisplayStringLineCol(7, 11, "PF8    GND" );		
					LCD_SetTextColor(LIGHTRED);
					LCD_DisplayStringLineCol(7, 3, "Connect " );		
					LCD_DisplayStringLineCol(7, 15, "to" );		
			  if (GPIOF->IDR & Bit(8))
				{
					LCD_DisplayStringLineCol(4, 16, "1" );		
					temp1= 0;
				}
				else
				{
					LCD_SetTextColor(GREEN);
					LCD_DisplayStringLineCol(4, 16, "0" );		
					LCD_DisplayStringLineCol(7, 18, "3.3V" );		
					temp1= 1;
				}
	// --- In hardware, CONNECT PF8 to GND or 3.3V
	//=================
	LCD_SetBackColor(DARKBLUE);
	LCD_DisplayStringLineCol(8, 5, "and Press KEY1" );		
	Wait_PressPA0(10);	
	while(GPIOA->IDR & Bit(0))			// wait until release KEY1
//====================================
				LCD_SetBackColor(DARKGRAY);
				LCD_DisplayStringLineCol(4, 5, "PF8 inputs " );		
				LCD_SetTextColor(GREEN);
			  if (GPIOF->IDR & Bit(8))
				{
					LCD_DisplayStringLineCol(4, 16, "1" );		
					if (temp1 != 1){
						LCD_DisplayStringLineCol(5, 2, "ERROR in setting PF8" );
					}
				}
				else
				{
					LCD_DisplayStringLineCol(4, 16, "0" );		
					if (temp1 != 0){
						LCD_DisplayStringLineCol(5, 2, "ERROR in setting PF8" );
					}
				}
	// --- In hardware, DISCONNECT PF8 to GND
	//=================
	LCD_SetBackColor(LIGHTRED);
	LCD_DisplayStringLineCol(7, 5, "DISconnect PF8" );		
	LCD_DisplayStringLineCol(8, 5, "and Press KEY1" );		
	Wait_PressPA0(10);	
	while(GPIOA->IDR & Bit(0))			// wait until release KEY1
//====================================
	LCD_SetColors(CYAN2, BLUE);
	LCD_DisplayStringLineCol(5, 8, "END of" );
	LCD_DisplayStringLineCol(7, 3, "SPI pins setting" );
	while(1) {}
#endif
