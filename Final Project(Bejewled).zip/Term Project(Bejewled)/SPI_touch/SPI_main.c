/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "stm324xg_lcd_sklin.h"
#include "touch_module.h"
#include <stdio.h>


static void delay(__IO uint32_t nCount);

void stm32f4_Hardware_Init (void);
void Driver_GPIO(void);
void Wait_PressPA0(uint16_t Cnum);
void Driver_SPIpin_GPIO(void);

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
	
#ifndef Bit
#define Bit(x) (0x01ul<<x)
#endif

#ifdef FPEC_Ram
#include "user_defined.h"
#define Flash_Sector4 0x08010000
#define Flash_Sector5 0x08020000
#define Flash_Sector6 0x08040000
#define Flash_Sector7 0x08060000
#define p_bmp Flash_Sector6
#define p_StAdd Flash_Sector4

uint32_t BMP_check_show(uint16_t x_pixel, uint16_t y_pixel, uint8_t *p_BmpAdd);
void Flash_Erase_for_Write(uint32_t beginSector, uint32_t endSector);
void ChangeBMP_24bit_to_16bit(uint8_t * p_BMPAdd, uint8_t * p_storeAdd);
#endif

int main(void)
{	
#ifdef FPEC_Ram
	uint32_t bitCount;
#endif
	stm32f4_Hardware_Init ();
	
	//TFT intialization
	Driver_GPIO();
	
	LCD_Init();

	LCD_DisplayOn();
  LCD_Clear(LCD_COLOR_GREEN);
	
	LCD_SetFont(&Font20);
	LCD_SetColors(RED, BLUE);
	LCD_DisplayStringAt(36, 140, (char*)"Press Key1    ", LEFT_MODE);
	LCD_DisplayStringAt(36, 160, (char*)"then Release ", LEFT_MODE);
	
	Wait_PressPA0(10);
	while(GPIOA->IDR & Bit(0));
	Driver_SPIpin_GPIO();

#ifdef Test_SPI_pin_Settings
		uint8_t temp1;
	GPIOF->BSRR = Bit(9)<<16;
			  if (GPIOF->IDR & Bit(9))
				{
					LCD_DisplayStringLineCol(2, 4, "1. PF9 outputs \"1\"" );		
					LCD_DisplayStringLineCol(3, 2, "ERROR in setting PF9" );
					while(1);
				}
				else
					LCD_DisplayStringLineCol(2, 4, "1. PF9 outputs \"0\"" );		
	GPIOF->BSRR = Bit(9);
			  if (GPIOF->IDR & Bit(9))
				{
					LCD_DisplayStringLineCol(3, 4, "2. PF9 outputs \"1\"" );		
					LCD_DisplayStringLineCol(4, 2, "PF9 setting succeeds." );
				}
				else
				{
					LCD_DisplayStringLineCol(3, 4, "2. PF9 outputs \"0\"" );		
					LCD_DisplayStringLineCol(4, 2, "ERROR in setting PF9" );
					while(1);
				}					

	//=================
	LCD_SetBackColor(CYAN2);
	LCD_DisplayStringLineCol(8, 5, "Press KEY1" );		
	Wait_PressPA0(10);	
	while(GPIOA->IDR & Bit(0))			// wait until release KEY1
//====================================
	if ((GPIOB->IDR & (Bit(1)| Bit(2))) != 0x04)
	{
					LCD_DisplayStringLineCol(2, 2, "ERROR in setting PB" );
					while(1);
	}
	GPIOB->BSRR = Bit(2)<<16;
	GPIOB->BSRR = Bit(1);
	if ((GPIOB->IDR & (Bit(1)| Bit(2))) != 0x02)
	{
					LCD_DisplayStringLineCol(2, 2, "ERROR in setting PB" );
					while(1);
	}
	else
					LCD_DisplayStringLineCol(2, 2, "PB setting succeeds." );

//======== Input GPIO PF8 setting Checking ===============
					LCD_SetColors(WHITE, DARKGRAY);
					LCD_DisplayStringLineCol(4, 5, "PF8 inputs " );		
					LCD_DisplayStringLineCol(7, 11, "PF8    GND" );		
					LCD_SetTextColor(LIGHTRED);
					LCD_DisplayStringLineCol(7, 3, "Connect " );		
					LCD_DisplayStringLineCol(7, 15, "to" );		
			  if (GPIOF->IDR & Bit(8))
				{
					LCD_DisplayStringLineCol(4, 16, "1" );		
					temp1= 0;
				}
				else
				{
					LCD_SetTextColor(GREEN);
					LCD_DisplayStringLineCol(4, 16, "0" );		
					LCD_DisplayStringLineCol(7, 18, "3.3V" );		
					temp1= 1;
				}
	// --- In hardware, CONNECT PF8 to GND or 3.3V
	//=================
	LCD_SetBackColor(DARKBLUE);
	LCD_DisplayStringLineCol(8, 5, "and Press KEY1" );		
	Wait_PressPA0(10);	
	while(GPIOA->IDR & Bit(0))			// wait until release KEY1
//====================================
				LCD_SetBackColor(DARKGRAY);
				LCD_DisplayStringLineCol(4, 5, "PF8 inputs " );		
				LCD_SetTextColor(GREEN);
			  if (GPIOF->IDR & Bit(8))
				{
					LCD_DisplayStringLineCol(4, 16, "1" );		
					if (temp1 != 1){
						LCD_DisplayStringLineCol(5, 2, "ERROR in setting PF8" );
					}
				}
				else
				{
					LCD_DisplayStringLineCol(4, 16, "0" );		
					if (temp1 != 0){
						LCD_DisplayStringLineCol(5, 2, "ERROR in setting PF8" );
					}
				}
	// --- In hardware, DISCONNECT PF8 to GND
	//=================
	LCD_SetBackColor(LIGHTRED);
	LCD_DisplayStringLineCol(7, 5, "DISconnect PF8" );		
	LCD_DisplayStringLineCol(8, 5, "and Press KEY1" );		
	Wait_PressPA0(10);	
	while(GPIOA->IDR & Bit(0))			// wait until release KEY1
//====================================
	LCD_SetColors(CYAN2, BLUE);
	LCD_DisplayStringLineCol(5, 8, "END of" );
	LCD_DisplayStringLineCol(7, 3, "SPI pins setting" );
	while(1) {}
#endif



	while(1)
	{
		uint16_t X_t, Y_t;
		char text[64];
		if (TSC_TouchDet(1)){
			Touch_GetVal(&X_t, &Y_t);
			LCD_SetColors(ORANGE, BLUE);
			LCD_DisplayStringLineCol(5, 5, "Touched");
		}
		else {
			X_t = 0;
			Y_t = 0;
			LCD_SetColors(YELLOW,LIGHTBLUE);
			LCD_FillRect(70,100,100,20);
			
		}
		LCD_SetColors(RED, GREEN);
		sprintf(text, "touch : X=%05d Y=%05d  ",X_t,Y_t);
		LCD_DisplayStringAtLine(7, (char *) text);
		
	}
}


static void delay(__IO uint32_t nCount)
{
  __IO uint32_t index = 0;
//  for(index = (100000 * nCount); index != 0; index--)
  for(index = (10000 * nCount); index != 0; index--)
  {
  }
}

void Wait_PressPA0(uint16_t Cnum)
{
  uint16_t keyTimer = Cnum;
	while(1)
	{
		if(GPIOA->IDR & Bit(0))
		{
			if(--keyTimer==0){
				LCD_Clear(YELLOW);
				return;
			}
			
			
		}else keyTimer = Cnum;
		
		delay(10);
	}
}

