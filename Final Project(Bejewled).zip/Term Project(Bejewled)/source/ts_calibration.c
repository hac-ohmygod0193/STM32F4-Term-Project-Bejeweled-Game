
/* Includes ------------------------------------------------------------------*/
#include "touch_module.h"
#include <stdio.h>	// for sprintf

/** @addtogroup STM32F4xx_HAL_Examples
  * @{
  */

/** @addtogroup BSP
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define TouchValue_16bits
#ifdef	TouchValue_16bits
	#define Q_format 16384 // Q14
#else			// TouchValue_12bits
	#define Q_format 1024 // Q10
#endif
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern uint8_t Calibration_Done;
extern int32_t  X1, Y1, Xx, Yx, Xy, Yy ;


/* Private function prototypes -----------------------------------------------*/
static void TouchscreenCalibration_SetHint(void);
static void GetPhysValues(int32_t LogX, int32_t LogY, int32_t* pPhysX, int32_t* pPhysY) ;

/* Private functions ---------------------------------------------------------*/
#include "user_defined.h"

#define ABS(X)  ((X) > 0 ? (X) : -(X))
/**
  * @brief  Performs the TS calibration
  * @param  None
  * @retval None
	*	X1: X_origin * Q_format
	* X2: slopeX * Q_format
	*	Y1: Y_origin * Q_format
	* Y1: slopeY * Q_format
	
	  Lx = aLogX[0]  + slopeX * (x_t - aPhysX[0]) 
		   = (aLogX[0] * Q  + (slopeX*Q) * (x_t - aPhysX[0]) )/Q
			 = ( (aLogX[0] * Q  - (slopeX*Q) *  aPhysX[0] ) + ((slopeX*Q) * x_t) )/Q
			 = (X1 + Xx* x) /Q
  */
void Touchscreen_Calibration (void)
{ 
  uint8_t i = 0;
  int32_t aPhysX[2], aPhysY[2], aLogX[2], aLogY[2];

  TouchscreenCalibration_SetHint();
  
  while (1)
  {
		uint16_t  XL, YL;
		int32_t	touchDiffX, touchDiffY;
		char text[64];
		int32_t	temp;
		
      aLogX[0] = 15;
      aLogY[0] = 15;
      aLogX[1] = BSP_LCD_GetXSize() - 15;
      aLogY[1] = BSP_LCD_GetYSize() - 15;
      
      for (i = 0; i < 2; i++) 
      {
        GetPhysValues(aLogX[i], aLogY[i], &aPhysX[i], &aPhysY[i]);
      }

			touchDiffX = aPhysX[1] - aPhysX[0];
			touchDiffY = aPhysY[1] - aPhysY[0];
			temp = aPhysX[0] / aPhysY[0] + aPhysY[0] / aPhysX[0];
			i = 0;			// switchXY = 0;
			if (temp > 2){
					i = 1;		// switchXY = 1;
			}

			if (i == 1){				// switchXY = i = 1
				temp = touchDiffX;
				touchDiffX = touchDiffY;
				touchDiffY = temp;
				X1 = aPhysY[0];
				Y1 = aPhysX[0];
			}else
			{
				X1 = aPhysX[0];
				Y1 = aPhysY[0];
			}
				
      Xx = (Q_format * ( aLogX[1] - aLogX[0]))/ ( touchDiffX ); 
      X1 = (Q_format * aLogX[0]) - Xx * X1; 
      
      Yy = (Q_format * ( aLogY[1] - aLogY[0]))/ ( touchDiffY ); 
      Y1 = (Q_format * aLogY[0]) -  Yy * Y1; 
      
			if (i == 1){				// switch = 1
				Xy = Xx;
				Yx = Yy;
				Xx = 0;
				Yy = 0;
			}

      Calibration_Done = 1;

			LCD_Clear(WHITE);

			LCD_SetColors(BLUE, WHITE);
			LCD_DisplayStringLineCol(6, 2, "Coefficients:   ");					
				LCD_DisplayStringLineCol(7, 2, "x_LCD = (X1 + Xx * X_tch + Xy * Y_tch)/1024 ");					
				LCD_DisplayStringLineCol(8, 2, "y_LCD = (Y1 + Yx * X_tch + Yy * Y_tch)/1024 ");					

				sprintf(text, "X1 = %07d, Xx =  %07d, Xy =  %07d", X1, Xx, Xy);
				LCD_DisplayStringLineCol(10, 2, text);					
				sprintf(text, "Y1 = %07d, Yx =  %07d, Yy =  %07d", Y1, Yx, Yy);
				LCD_DisplayStringLineCol(11, 2, text);					
			
			LCD_SetFont(&Font20);
			LCD_SetColors(RED, BLUE);
			XL = BSP_LCD_GetXSize();
			YL = BSP_LCD_GetYSize();
			LCD_DisplayStringAt(XL/2-60, YL-60, (char*)"  Close  ", LEFT_MODE);
			
			Touch_sensing(5, XL/2-60, YL-60, (Font20.Width)*9, (Font20.Height) );
			LCD_SetTextColor(WHITE);
			LCD_FillRect(XL/2-60, YL-60, (Font20.Width)*9, (Font20.Height));
			WaitForTouchRelease(5);
      return;
  }
}



void Touch_GetVal(uint16_t *pX, uint16_t *pY);
void Cal_GetXY(uint16_t* pX, uint16_t* pY);

/**
  * @brief  Display calibration hint
  * @param  None
  * @retval None
  */
static void TouchscreenCalibration_SetHint(void)
{
  /* Clear the LCD */ 
  LCD_Clear(LCD_COLOR_WHITE);
  
  /* Set Touchscreen Demo description */
  LCD_SetTextColor(LCD_COLOR_BLACK);
  LCD_SetBackColor(LCD_COLOR_WHITE);

  LCD_SetFont(&Font12);
  LCD_DisplayStringAt(0, BSP_LCD_GetYSize()/2 - 27, (char *)"Before using the Toucscreen", CENTER_MODE);
  LCD_DisplayStringAt(0, BSP_LCD_GetYSize()/2 - 12, (char *)"you need to calibrate it.", CENTER_MODE);
  LCD_DisplayStringAt(0, BSP_LCD_GetYSize()/2 + 3, (char *)"Press on the black circles", CENTER_MODE);
}



void Draw_donut(int16_t x, int16_t y, int16_t Color_out, int16_t radius)
{
  LCD_SetTextColor(Color_out);
  LCD_FillCircle(x, y, radius);
  LCD_SetTextColor(LCD_COLOR_WHITE);
  LCD_FillCircle(x, y, 2);
}
/**
  * @brief  Get Physical position
  * @param  LogX : logical X position
  * @param  LogY : logical Y position
  * @param  pPhysX : Physical X position
  * @param  pPhysY : Physical Y position
  * @retval None
  */
static void GetPhysValues(int32_t LogX, int32_t LogY, 
	      int32_t* pPhysX, int32_t* pPhysY) 
{
	uint16_t X_t, Y_t, count;		
#define CountNUM 50	
	count = CountNUM;

  /* Draw the ring */
	Draw_donut(LogX, LogY, BLACK, 5);
  
  /* Wait until touch is pressed */
  //WaitForPressedState(1);
	while(1)
  {
		if (TSC_TouchDet(1) == 1)
    {
			Draw_donut(LogX, LogY, RED, 8);			// callback function
      if(--count == 0) break;
		} else
		{
			count = CountNUM;
		}
    delay_ms(10);
  }
  LCD_SetTextColor(WHITE);
  LCD_FillCircle(LogX, LogY, 8);

  
	Touch_GetVal(&X_t, &Y_t);   // get x, y from touch module 
	
  *pPhysX = X_t;
  *pPhysY = Y_t; 
  
  /* Wait until touch is released */
	WaitForTouchRelease(CountNUM);
}



/**check if the TS is calibrated
  * @param  None
* @retval calibration state (1 : calibrated / 0: no)
  */
uint8_t IsCalibrationDone(void)
{
  return (Calibration_Done);
}

void SkipCalibration(void)
{
  Calibration_Done=1;
}

void RedoCalibration(void)
{
  Calibration_Done=0;
}

/**
  * @}
  */
  
/**
  * @}
  */ 
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
