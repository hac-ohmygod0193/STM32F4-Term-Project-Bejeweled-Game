#include "touch_module.h"
#include <stdio.h>	// for sprintf

#ifndef Bit
#define Bit(x) 	(0x01ul<<x)
#endif

#define point_Count  5
Point Points[point_Count]={ 
{5, 5}, {315,5}, {5, 235}, {315, 235}, {160, 120} }; 

/* Private variables ---------------------------------------------------------*/
static TS_StateTypeDef  TS_State;
/* Private function prototypes -----------------------------------------------*/
void delay_ms(uint32_t wait_ms);
static void Draw_sample(Point* pPts, uint16_t cnt);
void Draw_cross(uint16_t x, uint16_t y, uint16_t Color, uint16_t CenColor);


/**
  * @brief  Touchscreen play & pause
  * @param  None
  * @retval None
  */
void Touch_sample2 (void)
{ 
	char praises[4][10] = {" Bravo ", " Superb ", "Way to go", "My Idol"};
  uint16_t x, y, i,p_x,p_y;
  uint8_t state[point_Count], C_finish, prIndex=0;

#define KEY_LONGTIME 10 
#define BackColor	LCD_COLOR_GREEN	
	uint16_t KeyTimer = KEY_LONGTIME;  
 	//----------------------------------
re_start:	
	LCD_SaveColors();
	LCD_SaveFont();
	LCD_SetFont(&Font16);
	
	LCD_Clear(BackColor);
	while(GPIOA->IDR & 0x01)			// wait until release KEY1
    delay_ms(20);						// wait 20 msec for debouncing
	WaitForTouchRelease(3);
	
	//----------------------------------
 	Draw_sample(Points, point_Count);
	LCD_SetColors(LCD_COLOR_DARKBLUE, BackColor);
	LCD_DisplayStringLineCol(3, 2, "Touch Centers of Crosses!");					
	C_finish = point_Count;
	for (i=0; i<point_Count; i++)
	{
		state[i] = 0;
	}

	while (1)
  {
      TS_GetState(&TS_State);
      x = TS_State.x;
      y = TS_State.y;

		if(TS_State.TouchDetected)
		{
				char text[64];
//>>>------Assignment-----------------------
		//###==== 	
		 for (i=0; i<point_Count; i++)
		 {
			if( state[i] == 0 )
			{

				
//================
					LCD_SetColors(LCD_COLOR_RED, LCD_COLOR_WHITE); // Text = red; back = white
						sprintf(text, "Hit Point: x=%04d y=%04d", x, y);
				  LCD_DisplayStringLineCol(13, 2, text);					
//================	
					p_x = Points[i].X;
					p_y = Points[i].Y;
					if(x<p_x+3 && x>p_x-3)
					{
						if(y<p_y+3 && y>p_y-3){
							state[i]=1;
							C_finish=C_finish-1;
							Draw_cross(p_x,p_y,BackColor,BackColor);
							break;
						}	
					}	
					else{
						
					}	
														// state[i] = ?
															// C_finish = ?
												// x for "Draw_cross"
															// y for "Draw_cross"
															// call "Draw_cross"
						
			}	  // END of if( state[i] == 0 )
		 }		// END of for (i=0; i<point_Count; i++)
//<<<<--------------------------
		 
			if (C_finish == 0){
				LCD_SetFont(&Font20);
				LCD_SetColors(LCD_COLOR_RED, LCD_COLOR_BLUE);
				x = BSP_LCD_GetXSize();
				y = BSP_LCD_GetYSize();
				LCD_DisplayStringAt(x/2-60, y-60, praises[prIndex++], LEFT_MODE);
				if(prIndex == 4) prIndex = 0;
			
				Touch_sensing(5,x/2-60, y-60, (Font20.Width)*9, (Font20.Height));
				LCD_SetTextColor(BackColor);
				LCD_FillRect(x/2-60, y-60, (Font20.Width)*9, (Font20.Height));
				WaitForTouchRelease(5);
				goto re_start;
			}
		
		}	//	END of if(TS_State.TouchDetected)

	
    if(GPIOA->IDR & Bit(0))						// normally low
    {
			if (--KeyTimer==0){
				LCD_RestoreColors();
				LCD_RestoreFont();
				return;
			}
		} else KeyTimer = KEY_LONGTIME;
    
    
    delay_ms(10);
  }
}

//--------------------------------
void Vline_draw(int16_t x, int16_t y, uint16_t lg)
{
	if (x < 0) return;
	if (y < 0){
		lg = lg + y;
		y = 0;
	}
	LCD_DrawVLine(x, y, lg);
}

//-----------------------------
void Hline_draw(int16_t x, int16_t y, uint16_t lg)
{
	if (y < 0) return;
	if (x < 0){
		lg = lg + x;
		x = 0;
	}
	LCD_DrawHLine(x, y, lg);
}


//=========================================================
void Draw_cross(uint16_t x, uint16_t y, uint16_t Color, uint16_t CenColor)
{
	#define L	 16
	#define S		L-2
	#define hL	L/2
	LCD_SetTextColor(Color);
	
	Vline_draw(x-1, y-(hL-1), S);
	Vline_draw(x, y-hL, L);
	Vline_draw(x+1, y-7, S);
	Hline_draw(x-(hL-1), y-1, S);
	Hline_draw(x-hL, y, L);
	Hline_draw(x-(hL-1), y+1, S);
	LCD_DrawPixel(x, y, CenColor);
}

static void Draw_sample(Point* pPts, uint16_t cnt)
{
	uint16_t xp, yp,  i;
	

	for (i=0; i<cnt; i++)
	{
			xp = pPts[i].X;
			yp = pPts[i].Y;
			Draw_cross( xp, yp, LCD_COLOR_RED, LCD_COLOR_WHITE);
	}
}


