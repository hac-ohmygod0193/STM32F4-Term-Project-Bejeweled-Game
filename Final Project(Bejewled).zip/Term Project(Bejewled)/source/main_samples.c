/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "stm324xg_lcd_sklin.h"
#include "user_defined.h"
#include <stdio.h>	// for sprintf
#include "touch_module.h"


//uint32_t fg_Bt; // fg_Sl

void stm32f4_Hardware_Init (void);
void Wait_PressPA0(uint16_t Cnum);

void Driver_GPIO(void);
void Driver_SPIpin_GPIO(void);

void Default_Calibration(void);
//void Touchscreen_demo (void);
//void Touchscreen_playFig(void);

void Touchscreen_Calibration (void);
void Touch_sample1(void);
void Touch_sample2(void);
void Touch_sample3(void);

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main(void)
{
#define KEY_TIME 10  
 uint16_t keyTimer = KEY_TIME,cnt=0;  

	stm32f4_Hardware_Init();

	/* Initialize the LCD */
	LCD_Init();
	LCD_Clear(LIGHTMAGENTA);
	LCD_DisplayOn();
	
	/* Initialize the Touch module */
	Default_Calibration();
	Driver_GPIO();
	Driver_SPIpin_GPIO();

//	Touchscreen_Calibration();

startup:
	while(GPIOA->IDR & 0x01)			// wait until release KEY1
    delay_ms(20);						// wait 20 msec for debouncing

	LCD_SetFont(&Font20);
	LCD_SetColors(RED, BLUE);
	char str[10];
	LCD_DrawBitmap(0, 0, (uint8_t *) 0x08040000);
	snprintf(str, sizeof(str), "%d", cnt);
	
//=================
//====================================

//>>>>===== Scinario 0 =======================		
	//LCD_Clear(GREEN);
	//Sample_alarmA ();

//>>>>===== Scinario 1 =======================		
	
	//LCD_DrawBitmap(0, 0, (uint8_t *) 0x08050000);
	Bejeweled();
	goto startup;
}
//===============================
void Wait_PressPA0(uint16_t Cnum)
{
	uint16_t count = Cnum;
	while(1)
	{	
    if(GPIOA->IDR & Bit(0))						// normally low
    {
			if (--(count)==0){
				return;
			}
		} else count = Cnum;

    delay_ms(10);
	}
}





