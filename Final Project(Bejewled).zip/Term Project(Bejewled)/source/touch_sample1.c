#include "touch_module.h"
#include "stm32f4xx.h"
#include <stdio.h>	// for sprintf
#include <time.h>
#include <stdlib.h>
#define ABS(X)  ((X) > 0 ? (X) : -(X))
#ifndef Bit
#define Bit(x) 	(0x01ul<<x)
#endif

/* Private variables ---------------------------------------------------------*/
static TS_StateTypeDef  TS_State;


/* Private function prototypes -----------------------------------------------*/
void delay_ms(uint32_t wait_ms);
void Touch_ChooseColor(uint16_t Val, uint16_t lastVal);
static void Draw_sample(void);
void Draw_cross(uint16_t x, uint16_t y, uint16_t Color, uint16_t CenColor);
static void Game(void);
#define R_w	44
#define	R_h	60
#define ColorBoxes_x	(319-R_w)
#define Color0_y	0
#define Color1_y	(R_h-1)
#define Color2_y	(2*R_h-1)
#define Color3_y	(3*R_h-1)
#define GRID_SIZE 8
#define MAX_KIND 7
#define TILE_SIZE 30
/**
  * @brief  Touchscreen
  * @param  None
  * @retval None
  */
	

int final_score=0;
int isMoving = 0;
int Falling = 0;
int startgame = 1;
int delay = 50;
int fall[8]={0};
int combo=0;
int clk=0;
int life=200;
int level=1;
float bonus=1;
struct piece
{
  uint16_t x, y, col, row, kind, match, alpha, change;
};

struct piece grid[GRID_SIZE][GRID_SIZE];

void swap(struct piece p1, struct piece p2) {
  uint16_t temp1,temp2;
	temp1 = grid[p1.row][p1.col].kind;
	grid[p1.row][p1.col].kind = grid[p2.row][p2.col].kind;
	grid[p2.row][p2.col].kind = temp1;
	
	temp2 = grid[p1.row][p1.col].match;
	grid[p1.row][p1.col].match = grid[p2.row][p2.col].match;
	grid[p2.row][p2.col].match = temp2;
	
}

void MatchGems()
{
	if(life>240) life=240;
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 8; j++) {
			int ismatched=0;
			int score;
			if (i<6 && grid[i][j].kind == grid[i+1][j].kind && grid[i][j].kind == grid[i+2][j].kind) {
				if (grid[i][j].kind == grid[i+2][j].kind) {
					if(grid[i+1][j].match==0){
						combo++;
						life+=(10+combo);
						if(life>240) life=240;
						for(int i=1;i<9;i++)
						{
							LCD_SetTextColor(BROWN);
							LCD_DrawVLine(240+i,0,240-life);
							LCD_SetTextColor(GREEN);
							LCD_DrawVLine(240+i,240-life,240);
						}
					}
					else ismatched=1;
					int k=0;
					while(grid[i][j].kind==grid[i+k][j].kind)
					{
						grid[i+k][j].match=1;
						isMoving=1;
						if(i+k==7) break;
						k++;
					}
					if(ismatched) continue;
					switch(k){
						case 3:
							score=1;
							break;
						case 4:
							score=20;
							break;
						case 5:
							score=30;
							break;
						case 6:
							score=50;
							break;
						case 7:
							score=100;
							break;
						case 8:
							score=100;
							break;
						default:
							score=0;
							break;
					}
					final_score += (score*(level+1)*5*k);
				}
			}
			ismatched=0;
			if (j<6 && grid[i][j].kind == grid[i][j+1].kind && grid[i][j].kind == grid[i][j+2].kind) {
				if (grid[i][j].kind == grid[i][j+2].kind) {
					if(grid[i][j+1].match==0){
						combo++;
						life+=(5+combo);
						if(life>240) life=240;
						for(int i=1;i<9;i++)
						{
							LCD_SetTextColor(BROWN);
							LCD_DrawVLine(240+i,0,240-life);
							LCD_SetTextColor(GREEN);
							LCD_DrawVLine(240+i,240-life,240);
						}
					}
					else ismatched=1;
					int k=0;
					while(grid[i][j].kind==grid[i][j+k].kind)
					{
						grid[i][j+k].match=1;
						isMoving=1;
						if(j+k==7) break;
						k++;
					}
					if(ismatched) continue;
					switch(k){
						case 3:
							score=1;
							break;
						case 4:
							score=20;
							break;
						case 5:
							score=30;
							break;
						case 6:
							score=50;
							break;
						case 7:
							score=100;
							break;
						case 8:
							score=100;
							break;
						default:
							score=0;
							break;
					}
					final_score += (score*(level+1)*5*k);
				}
			}
		}
	}
	
}
void DrawGems(struct piece p){
			//if(p.row%2==p.col%2) LCD_SetTextColor(DARKMAGENTA);
			//else LCD_SetTextColor(DARKGRAY);
			LCD_SetTextColor(DARKMAGENTA);
			LCD_DrawCircle(p.x,p.y,TILE_SIZE/2-1);
			LCD_FillCircle(p.x,p.y,TILE_SIZE/2-2);
			switch(p.kind) //grid[i][j].kind
			{
				case 0:
					LCD_SetTextColor(LIGHTBLUE);
					break;
				case 1:
					LCD_SetTextColor(GREEN);
					break;
				case 2:
					LCD_SetTextColor(BLUE);
					break;
				case 3:
					LCD_SetTextColor(ORANGE);
					break;
				case 4:
					LCD_SetTextColor(RED);
					break;
				case 5:
					LCD_SetTextColor(YELLOW);
					break;
				case 6:
					LCD_SetTextColor(CYAN2);
					break;
				default:
					break;
			}
			if(p.y!=(p.row * TILE_SIZE + TILE_SIZE/2)){
				grid[p.row][p.col].y+=TILE_SIZE/2;
				p.y = grid[p.row][p.col].y;
				Falling=1;
				fall[p.col]=1;
			}
			LCD_FillCircle(p.x,p.y,TILE_SIZE/2-2);
}

void UpdateGems(struct piece p)
{
			if(p.match==1){
				LCD_SetTextColor(DARKMAGENTA);
				LCD_DrawCircle(grid[p.row][p.col].x,grid[p.row][p.col].y,TILE_SIZE/2-1);
				LCD_FillCircle(grid[p.row][p.col].x,grid[p.row][p.col].y,TILE_SIZE/2-2);
				for(int i=p.row;i>=1;i--){
					grid[i][p.col].kind = grid[i-1][p.col].kind;
					grid[i][p.col].match = grid[i-1][p.col].match;
					grid[i][p.col].y = grid[i-1][p.col].y;
				}
				grid[0][p.col].kind = rand()% MAX_KIND;
				grid[0][p.col].match = 0;
				grid[0][p.col].y = grid[0][p.col].y-TILE_SIZE;
				UpdateGems(grid[p.row][p.col]);
			}
}
void blink(){
	for(int j=0;j<=7;j++)
	{
			for(int i=7;i>=0;i--)
			{
				if(grid[i][j].match==1){
					DrawGems(grid[i][j]);
				}
			}
			
	}
	delay_ms(100);
	for(int j=0;j<=7;j++)
	{
			for(int i=7;i>=0;i--)
			{
				if(grid[i][j].match==1){
					LCD_SetTextColor(DARKMAGENTA);
					LCD_DrawCircle(grid[i][j].x,grid[i][j].y,TILE_SIZE/2-1);
					LCD_FillCircle(grid[i][j].x,grid[i][j].y,TILE_SIZE/2-2);
				}
			}
			
	}
	delay_ms(100);
}
void DrawGrid() {
		Falling = 0;
		for(int j=0;j<=7;j++)
		{
			if(fall[j]==1){
				fall[j]=0;
				for(int i=7;i>=0;i--)
				{
					DrawGems(grid[i][j]);
				}
			}
		}
		LCD_SetTextColor(GRAY);
		LCD_DrawHLine(0,240,240);
		if(Falling){
			delay_ms(200);
			DrawGrid();
		}
}
void updateGrid() {
	isMoving=0;
	MatchGems();
	if(isMoving){
		for(int j=0;j<=7;j++)
		{
			fall[j]=1;
			for(int i=7;i>=0;i--)
			{
				UpdateGems(grid[i][j]);
			}
		}
		updateGrid();
	}
}

	

void initializeGrid()
{
  isMoving = 0;
	for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      grid[i][j].kind = rand() % MAX_KIND;
			grid[i][j].col = j;
			grid[i][j].row = i;
      grid[i][j].x = j * TILE_SIZE + TILE_SIZE/2;
      grid[i][j].y = i * TILE_SIZE + TILE_SIZE/2;
			grid[i][j].match = 0;
    }
  }
	updateGrid();
	for (int i = 0; i < GRID_SIZE; i++)
  {
    for (int j = 0; j < GRID_SIZE; j++)
    {
      grid[i][j].x = j * TILE_SIZE + TILE_SIZE/2;
      grid[i][j].y = i * TILE_SIZE + TILE_SIZE/2-240;
			grid[i][j].match = 0;
    }
  }
	DrawGrid();
	LCD_SetTextColor(GRAY);
	for(int i=1;i<9;i++){
		LCD_DrawVLine(30*i,0,240);
		//LCD_DrawHLine(0,30*i,240);
	}
	LCD_DrawHLine(0,240,240);
	for(int i=0;i<8;i++)
	{
		for(int j=0;j<8;j++)
		{
			//if(p.row%2==p.col%2) LCD_SetTextColor(DARKMAGENTA);
			//else LCD_SetTextColor(DARKGRAY);
			LCD_SetTextColor(DARKMAGENTA);
			LCD_FillRect(30*j,30*i,30,30);
			DrawGems(grid[i][j]);
		}
	}
	LCD_SetTextColor(BROWN);
	LCD_DrawVLine(240,0,240);
	LCD_DrawVLine(249,0,240);
	LCD_SetTextColor(GREEN);
	for(int i=1;i<9;i++)
	{
		LCD_SetTextColor(BROWN);
		LCD_DrawVLine(240+i,0,240-life);
		LCD_SetTextColor(GREEN);
		LCD_DrawVLine(240+i,240-life,240);
	}
	startgame=0;
}


void PlayGems()
{
    
		int x0 = -1, y0 = -1;
		int x1, y1, x, y;
		int click = 0;
		int ts = TILE_SIZE;
		int isSwap=0;
		while(1)
		{
			delay_ms(1);
			
			if(clk==(160-level*10)){
				life-=1;
				for(int i=1;i<9;i++)
				{
					LCD_SetTextColor(BROWN);
					LCD_DrawVLine(240+i,0,240-life);
					LCD_SetTextColor(GREEN);
					LCD_DrawVLine(240+i,240-life,240);
				}
				clk=0;
			}
			else clk++;
			if(life==0) break;
			TS_StateTypeDef TS_State;
			TS_GetState(&TS_State);
			x = TS_State.x;
			y = TS_State.y;
			// screen click
			if (TS_State.TouchDetected && x <= 240 && y <= 240)
			{
					//if(p.row%2==p.col%2) LCD_SetTextColor(DARKMAGENTA);
					//else LCD_SetTextColor(DARKGRAY);
					LCD_SetTextColor(DARKMAGENTA);

					if (x0 != -1 && y0 != -1)
					{
							LCD_DrawRect(ts * x0+1, ts * y0+1,28, 28);
							click = 1;
					}

					x1 = x / ts;
					y1 = y / ts;

					WaitForTouchRelease(5);

					if ((x1 == x0 & (y1 == y0-1 || y1 == y0+1)) || (y1 == y0 & (x1 == x0-1 || x1 == x0+1))|| click==0)
					{
						combo=0;	
						if(click==0)
							{
								LCD_SetTextColor(WHITE);
								LCD_DrawRect(ts * x1+1, ts * y1+1, 28, 28);
								x0 = x1;
								y0 = y1;
								click = 1;
							}
							else
							{
								isMoving = 0;
								swap(grid[y0][x0],grid[y1][x1]);
								DrawGems(grid[y0][x0]);
								DrawGems(grid[y1][x1]);
								delay_ms(250);
								MatchGems();
								//DrawGems(grid[y0][x0]);
								//DrawGems(grid[y1][x1]);
								if(isMoving){
									LCD_SetFont(&Font20);
									LCD_SetColors(RED, BLUE);
									LCD_DisplayStringAt(250, 150, (char*)"GREAT", LEFT_MODE);
									for(int i=0;i<2;i++) blink();
									updateGrid();
									DrawGrid();
								}
								else{
									
									swap(grid[y0][x0],grid[y1][x1]);
									DrawGems(grid[y0][x0]);
									DrawGems(grid[y1][x1]);
									LCD_SetFont(&Font20);
									LCD_SetColors(BLUE, RED);
									LCD_DisplayStringAt(250, 150, (char*)"RETRY", LEFT_MODE);
								}
								LCD_SetFont(&Font20);
								LCD_SetColors(WHITE, BLUE);
								
								switch(combo){
									case 0:
										break;
									case 1:
										break;
									case 2:
										final_score+=20;
										break;
									case 3:
										final_score+=60;
										break;
									case 4:
										final_score+=200;
										break;
									case 5:
										final_score+=350;
										break;
									case 6:
										final_score+=600;
										break;
									default:
										final_score+=150*combo;
										break;
									}
								
								char str1[10];
								snprintf(str1, sizeof(str1), "%5d", final_score);
								LCD_DisplayStringAt(250, 100, (uint8_t *)str1, LEFT_MODE);
								char str2[10];
								snprintf(str2, sizeof(str2), "%5d", combo);
								LCD_DisplayStringAt(250, 200, (uint8_t *)str2, LEFT_MODE);
								char str3[10];
								snprintf(str3, sizeof(str3), "%5d", level);
								LCD_DisplayStringAt(250, 50, (uint8_t *)str3, LEFT_MODE);
								break;
							}
							
					}
					else
					{
							x0 = -1;
							y0 = -1;
							click = 0;
					}
			}
		}
}
	

void ResetMatch(){
	for(int i=0;i<8;i++){
		for(int j=0;j<8;j++){
			grid[i][j].match=0;
		}
	}
}
void DrawBackground(){
	LCD_SetTextColor(GRAY);
				for(int i=1;i<9;i++){
					LCD_DrawVLine(30*i,0,240);
					//LCD_DrawHLine(0,30*i,240);
				}
				
				for(int i=0;i<8;i++)
				{
					for(int j=0;j<8;j++)
					{
						LCD_SetTextColor(DARKMAGENTA);
						LCD_FillRect(30*j,30*i,30,30);
					}
				}
				LCD_SetTextColor(BROWN);
				LCD_DrawVLine(240,0,240);
				LCD_DrawVLine(249,0,240);
				LCD_SetTextColor(BLUE);
				LCD_FillRect(250, 0, 70, 240);
				LCD_SetTextColor(GREEN);
				for(int i=1;i<9;i++)
				{
					LCD_DrawVLine(240+i,0,240);
				}
				
}
void ClearScreen(){
				LCD_Clear(WHITE);
				DrawBackground();
				LCD_SetFont(&Font20);
				LCD_SetColors(WHITE, BLUE);
				LCD_DisplayStringAt(250, 30, (char*)"LEVEL", LEFT_MODE);
				LCD_DisplayStringAt(250, 80, (char*)"SCORE", LEFT_MODE);
				LCD_DisplayStringAt(250, 180, (char *)"COMBO", LEFT_MODE);
				char str1[10];
				snprintf(str1, sizeof(str1), "%5d", final_score);
				LCD_DisplayStringAt(250, 100, (uint8_t *)str1, LEFT_MODE);
				char str2[10];
				snprintf(str2, sizeof(str2), "%5d", combo);
				LCD_DisplayStringAt(250, 200, (uint8_t *)str2, LEFT_MODE);
				char str3[10];
				snprintf(str3, sizeof(str3), "%5d", level);
				LCD_DisplayStringAt(250, 50, (uint8_t *)str3, LEFT_MODE);
				initializeGrid();
}
void Bejeweled (void)
{
  uint16_t x, y,cnt=100;
	int gameover=0;
	#define KEY_LONGTIME 10
	#define BackColor	WHITE
	uint32_t KeyTimer = KEY_LONGTIME;
	LCD_SetFont(&Font20);
	LCD_SetColors(RED, BLUE);
	LCD_DisplayStringAt(60, 220, (char*)"PLAY BEJEWELED", LEFT_MODE);
	Touch_sensing(5,60, 220, (Font24.Width)*9, (Font24.Height));
	LCD_SetTextColor(DARKMAGENTA);
	LCD_FillRect(60, 220, (Font24.Width)*9, (Font24.Height));
	//WaitForTouchRelease(0.1);
	LCD_Clear(DARKMAGENTA);
 	//----------------------------------
//re_start:
	while(1){
		LCD_Clear(WHITE);
		life=200;
		DrawBackground();
		startgame=1;
		LCD_SetFont(&Font20);
		LCD_SetColors(WHITE, BLUE);
		LCD_DisplayStringAt(250, 30, (char*)"LEVEL", LEFT_MODE);
		LCD_DisplayStringAt(250, 50, (char*)"    1", LEFT_MODE);
		LCD_DisplayStringAt(250, 80, (char*)"SCORE", LEFT_MODE);
		LCD_DisplayStringAt(250, 100, (char*)"    0", LEFT_MODE);
		LCD_DisplayStringAt(250, 180, (char *)"COMBO", LEFT_MODE);
		LCD_DisplayStringAt(250, 200, (char*)"    0", LEFT_MODE);
		while(1){
			cnt++;
			if(GPIOA->IDR & 0x01) break;
			if(startgame){
				startgame=0;
				DrawBackground();
				LCD_SetFont(&Font20);
				LCD_SetColors(WHITE, BLUE);
				LCD_DisplayStringAt(50, 100, (char*)"PRESS KEY1", LEFT_MODE);
				LCD_DisplayStringAt(50, 120, (char*)"TO START!!", LEFT_MODE);
				if(gameover){
					LCD_SetFont(&Font24);
					LCD_SetColors(RED, BLUE);
					LCD_DisplayStringAt(50, 30, (char*)"GAMEOVER", LEFT_MODE);
					LCD_SetFont(&Font20);
					LCD_SetColors(WHITE, BLUE);
					LCD_DisplayStringAt(250, 30, (char*)"LEVEL", LEFT_MODE);
					LCD_DisplayStringAt(250, 80, (char*)"SCORE", LEFT_MODE);
					LCD_DisplayStringAt(250, 180, (char *)"COMBO", LEFT_MODE);
					combo=0;
					char str1[10];
					snprintf(str1, sizeof(str1), "%5d", final_score);
					LCD_DisplayStringAt(250, 100, (uint8_t *)str1, LEFT_MODE);
					char str2[10];
					snprintf(str2, sizeof(str2), "%5d", combo);
					LCD_DisplayStringAt(250, 200, (uint8_t *)str2, LEFT_MODE);
					char str3[10];
					snprintf(str3, sizeof(str3), "%5d", level);
					LCD_DisplayStringAt(250, 50, (uint8_t *)str3, LEFT_MODE);
					gameover=0;
				}
				else {
					LCD_SetFont(&Font20);
					LCD_SetColors(WHITE, BLUE);
					LCD_DisplayStringAt(35, 15, (char*)"Instructions", LEFT_MODE);
					LCD_SetFont(&Font16);
					LCD_SetColors(WHITE, BLUE);
					LCD_DisplayStringAt(0, 50, (char*)"Click Two Adjacent Gems", LEFT_MODE);
					LCD_DisplayStringAt(0, 65, (char*)"To Swap Their Positons!", LEFT_MODE);
				}
			}
			
		}
		startgame=0;
		life=200;
		level = 1;
		final_score = 0;
		srand(cnt);
		ClearScreen();
		life=200;
		level = 1;
		final_score = 0;
		while(1)
		{
			PlayGems();
			ResetMatch();
			if(level!= final_score/5000+1){
				level = final_score/5000+1;
				x = BSP_LCD_GetXSize();
				y = BSP_LCD_GetYSize();
				LCD_DisplayStringAt(100, 100, (char*)"NEXT LEVEL", LEFT_MODE);
				delay_ms(500);
				life = 200;
				ClearScreen();
			}
			if(life==0)break;
		}
	//===========>>>>
		gameover=1;
	}
		//-------------------------------

//-------------------------
			/*
			Touch_sensing(5, x/2-30, y-60, (Font24.Width)*9, (Font24.Height));
			LCD_SetTextColor(WHITE);
			LCD_FillRect(x/2-30, y-60, (Font24.Width)*9, (Font24.Height));
			WaitForTouchRelease(3);
			*/
		
		
		

//<<<-------------------------

    if(GPIOA->IDR & Bit(0))						// normally low
    {
			if (--KeyTimer==0){
				LCD_RestoreColors();
				LCD_RestoreFont();
				return;
			}
		} else KeyTimer = KEY_LONGTIME;
		
	
  
}